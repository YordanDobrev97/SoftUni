﻿
public class SolarProvider : Provider
{

}

