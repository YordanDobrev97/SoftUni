﻿
public class HammerHarvester : Harvester
{
    public HammerHarvester()
    {
        
    }
}

