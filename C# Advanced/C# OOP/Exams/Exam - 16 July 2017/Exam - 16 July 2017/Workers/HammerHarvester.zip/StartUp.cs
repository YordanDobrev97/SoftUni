﻿using System;


public class StartUp
{
    public static void Main()
    {
        SonicHarvester sonicHarvester = new SonicHarvester(200);


    }
}

