﻿namespace MilitaryElite.Models
{
    public enum TypeCorps
    {
        Airforces,
        Marines
    }
}
