﻿namespace MilitaryElite.Models
{
    public enum State
    {
        inProgress,
        Finished
    }
}
