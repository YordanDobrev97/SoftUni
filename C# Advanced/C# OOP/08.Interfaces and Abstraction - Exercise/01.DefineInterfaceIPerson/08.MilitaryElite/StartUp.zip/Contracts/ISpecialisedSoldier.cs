﻿using MilitaryElite.Models;

namespace MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier
    {
        TypeCorps TypeCorps { get; }
    }
}
