﻿namespace MilitaryElite.Contracts
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
