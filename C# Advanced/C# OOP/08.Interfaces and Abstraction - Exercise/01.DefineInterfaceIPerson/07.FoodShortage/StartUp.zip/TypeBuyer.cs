﻿namespace FoodShortage
{
    public enum TypeBuyer
    {
        Rebel,
        Citizen
    }
}