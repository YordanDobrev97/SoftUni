﻿namespace FoodShortage
{
    public interface IIdentifiable : IBirthdable
    {
         string Id { get; }
    }
}
