﻿using System;

namespace FoodShortage
{
    public interface IBirthdable
    {
        public DateTime Birthday { get; }
    }
}
