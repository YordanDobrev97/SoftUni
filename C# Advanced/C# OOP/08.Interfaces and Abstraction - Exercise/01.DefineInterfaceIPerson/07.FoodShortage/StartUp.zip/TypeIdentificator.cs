﻿namespace FoodShortage
{
    public enum TypeIdentificator
    {
        Citizen,
        Robot,
        Pet
    }
}
