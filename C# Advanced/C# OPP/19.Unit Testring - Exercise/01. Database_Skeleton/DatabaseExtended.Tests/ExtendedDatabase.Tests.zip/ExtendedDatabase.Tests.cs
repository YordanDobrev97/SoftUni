using NUnit.Framework;
using System;

namespace Tests
{
    public class ExtendedDatabaseTests
    {
        [Test]
        public void Test_Add_Max_Person_Data()
        {
            Person[] persons = new Person[]
            {
                new Person(1,"Joni"),
                new Person(2,"Moni"),
                new Person(3,"Toni"),
                new Person(4,"Roni"),
                new Person(5,"Kiro"),
                new Person(6,"Miro"),
                new Person(7,"Ivo"),
                new Person(8,"Dido"),
                new Person(9,"Ivan"),
                new Person(10,"Stamat"),
                new Person(11,"Mariq"),
                new Person(12,"Petq"),
                new Person(13,"Ivana"),
                new Person(14,"Svetla"),
                new Person(15,"Elena"),
                new Person(16,"Viki"),
            };
            ExtendedDatabase database = new 
                ExtendedDatabase(persons);

            Assert.AreEqual(database.Count, 16);
        }

        [Test]
        public void Add_Person_Data()
        {
            ExtendedDatabase database = new
                ExtendedDatabase();

            database.Add(new Person(1, "Niki"));
            Assert.AreEqual(database.Count, 1);
        }

        [Test]
        public void Try_Add_With_Max_Capacity_Data()
        {
           ExtendedDatabase database = new
               ExtendedDatabase();

            string[] names = new string[]
            {
                "Ivi", "Mimi", "Vili", "Viki", "Petq", "Galq",
                "Ivo", "Kiro", "Dancho", "Nik", "Nikolay", "Deni",
                "Mariq", "Denislav", "Miro", "Stivi"
            };

            for (int i = 1; i <=16; i++)
            {
                database.Add(new Person(i, names[i - 1]));
            }
            
            Assert.Throws<InvalidOperationException>(() => database.Add(new Person(16, "Joni Test")));
        }

        [Test]
        public void Add_Exist_Person_Name()
        {
            ExtendedDatabase database = new
               ExtendedDatabase();

            database.Add(new Person(1, "Ivo"));
            Assert.Throws<InvalidOperationException>(() => database.Add(new Person(2, "Ivo")));
        }

        [Test]
        public void Add_Exist_Person_Id()
        {
            ExtendedDatabase database = new
                ExtendedDatabase();

            database.Add(new Person(1, "Ivo"));
            Assert.Throws<InvalidOperationException>(() => database.Add(new Person(1, "Kiro")));
        }

        [Test]
        public void Remove_Person_Success()
        {
            ExtendedDatabase database = new
               ExtendedDatabase();

            database.Add(new Person(1, "Pesho"));
            database.Remove();

            Assert.AreEqual(database.Count, 0);
        }

        [Test]
        public void Try_Remove_With_Empty_Data()
        {
            ExtendedDatabase database = new
               ExtendedDatabase();

            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }

        [Test]
        public void Find_By_User_Name_With_Null_Name()
        {
            ExtendedDatabase database = new
               ExtendedDatabase();

            database.Add(new Person(1, "Iva"));
            Assert.Throws<ArgumentNullException>(() => database.FindByUsername(null));
        }

        [Test]
        public void Find_By_User_Name_With_Not_Exist_Person()
        {
            ExtendedDatabase database = new
              ExtendedDatabase();

            Assert.Throws<InvalidOperationException>(() => database.FindByUsername("Ivo"));
        }

        [Test]
        public void Find_By_User_Name_Success()
        {
           ExtendedDatabase database = new
              ExtendedDatabase();

            var ivo = new Person(1, "Ivo");
            database.Add(ivo);
            Person person = database.FindByUsername("Ivo");
            Assert.AreEqual(person, ivo);
        }

        [Test]
        public void Find_By_Id_With_Negative_Id()
        {
            ExtendedDatabase database = new
              ExtendedDatabase();

            Assert.Throws<ArgumentOutOfRangeException>(() => database.FindById(-3));
        }

        [Test]
        public void Find_By_Id_Wit_Not_Exist_Person_Id()
        {
            ExtendedDatabase database = new
             ExtendedDatabase();

            Assert.Throws<InvalidOperationException>(() => database.FindById(3));
        }

        [Test]
        public void Find_By_Id_Success()
        {
            ExtendedDatabase database = new
             ExtendedDatabase();

            var ivo = new Person(1, "Ivo");
            database.Add(ivo);
            var personResult = database.FindById(1);

            Assert.AreEqual(ivo, personResult);
        }
    }
}