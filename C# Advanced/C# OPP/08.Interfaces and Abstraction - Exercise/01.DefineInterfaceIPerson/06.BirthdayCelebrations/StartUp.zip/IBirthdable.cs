﻿using System;

namespace BirthdayCelebrations
{
    public interface IBirthdable
    {
        public DateTime Birthday { get; }
    }
}
