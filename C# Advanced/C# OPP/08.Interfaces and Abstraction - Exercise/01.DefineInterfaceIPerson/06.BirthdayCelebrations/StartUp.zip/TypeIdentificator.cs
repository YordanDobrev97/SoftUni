﻿namespace BirthdayCelebrations
{
    public enum TypeIdentificator
    {
        Citizen,
        Robot,
        Pet
    }
}
