﻿namespace WildFarm.Enums
{
    public enum AnimalType
    {
        Cat,
        Dog,
        Hen,
        Mouse,
        Owl,
        Tiger
    }
}
