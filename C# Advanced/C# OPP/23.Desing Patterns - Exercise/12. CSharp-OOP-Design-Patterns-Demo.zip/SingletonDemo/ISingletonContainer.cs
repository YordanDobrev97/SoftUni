﻿namespace SingletonDemo
{
    public interface ISingletonContainer
    {
        int GetPopulation(string name);
    }
}