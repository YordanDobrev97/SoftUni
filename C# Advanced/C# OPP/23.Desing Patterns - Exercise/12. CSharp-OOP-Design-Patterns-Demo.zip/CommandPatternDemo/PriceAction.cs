﻿namespace CommandPatternDemo
{
    public enum PriceAction
    {
        Increase,
        Decrease
    }
}