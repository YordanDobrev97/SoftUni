﻿namespace CommandPatternDemo
{
    public interface ICommand
    {
        void ExecuteAction();
    }
}
