﻿using MortalEngines.IO;

namespace MortalEngines
{
    public class StartUp
    {
        public static void Main()
        {
            Command command = new Command();
            command.Execute();
        }
    }
}