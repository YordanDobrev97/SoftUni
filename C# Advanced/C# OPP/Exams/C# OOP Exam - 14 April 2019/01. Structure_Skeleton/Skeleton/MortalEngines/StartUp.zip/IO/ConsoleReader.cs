﻿using System;
using System.Collections.Generic;
using System.Linq;
using MortalEngines.IO.Contracts;

namespace MortalEngines.IO
{
    public class ConsoleReader : IReader
    {
        public IList<ICommand> ReadCommands()
        {
            
            return null;
        }
    }
}
