﻿namespace MortalEngines.IO
{
    public interface ICommand
    {
        void Execute();
    }
}
