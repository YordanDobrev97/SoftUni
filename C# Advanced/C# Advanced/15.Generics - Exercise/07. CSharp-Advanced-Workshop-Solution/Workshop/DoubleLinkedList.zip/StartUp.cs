﻿using System;
using System.Linq;

namespace Workshop
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
