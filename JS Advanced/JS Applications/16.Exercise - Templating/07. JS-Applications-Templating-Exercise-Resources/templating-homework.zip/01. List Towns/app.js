//I did extends the task for fun

import loadTowns from './loadTowns.js';
import addTown from './add-town.js';

document.getElementById('btnLoadTowns').addEventListener('click', loadTowns);
document.getElementById('add').addEventListener('click', addTown);
