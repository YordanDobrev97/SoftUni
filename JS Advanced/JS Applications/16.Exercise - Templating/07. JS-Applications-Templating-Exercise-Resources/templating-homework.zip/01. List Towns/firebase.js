const baseUrl = 'https://towns-36ce9.firebaseio.com/.json';

export default baseUrl;