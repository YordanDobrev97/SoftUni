I use handlebars.js the file locally and if you open the tasks separately 
there is a chance that it will not load handlebars.js

You must open the tasks together so that the file can be viewed and loaded!