export default {
    contentContainerId: 'mainContent',
    loginContainer: 'loginContainer',
    baseUrl: 'https://softunidemo-e35be.firebaseio.com/',
    firebaseConfig: {
        apiKey: "AIzaSyA6y3B46Jx0fD8yFgaLtuZQiQf5IKD20CQ",
        authDomain: "softunidemo-e35be.firebaseapp.com",
        databaseURL: "https://softunidemo-e35be.firebaseio.com/",
        projectId: "softunidemo-e35be",
        storageBucket: "softunidemo-e35be.appspot.com",
        messagingSenderId: "808784307686",
        appId: "1:808784307686:web:4f58905abe4fc322276227"
      },
      dataCollections: {
        todoCollection: 'todo',
        errorLogCollection: 'error_log'
      }
}