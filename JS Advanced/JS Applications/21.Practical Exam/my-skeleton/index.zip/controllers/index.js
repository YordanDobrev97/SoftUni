import home from './home.js';
import user from './user.js';
import cause from './cause.js';

export default {
    home,
    user,
    cause,
}