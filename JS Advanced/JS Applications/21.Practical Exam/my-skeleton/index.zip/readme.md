I use the following things:
1. Live-Server
2. Similar skeleton to Hristomir
3.Firestore for database

CSS it's a little broken, I don't know why

please, start in #/login because #/home not work, first register and after work