var firebaseConfig = {
    apiKey: "AIzaSyC2Qgvcjv93VtOivsFAhkjwkcaWMK4vHI8",
    authDomain: "examdb-95630.firebaseapp.com",
    databaseURL: "https://examdb-95630.firebaseio.com",
    projectId: "examdb-95630",
    storageBucket: "examdb-95630.appspot.com",
    messagingSenderId: "1088576150832",
    appId: "1:1088576150832:web:77bb9bbea4f3e26c6ffcf5"
};
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);