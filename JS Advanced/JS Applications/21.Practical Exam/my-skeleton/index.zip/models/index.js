import user from './user.js';
import cause from './cause.js';

export default {
    user,
    cause
}