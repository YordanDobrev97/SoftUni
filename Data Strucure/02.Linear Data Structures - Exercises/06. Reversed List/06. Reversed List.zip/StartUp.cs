﻿using System;
using System.Collections.Generic;
using System.Linq;
class StartUp
{
    static void Main()
    {
        ReversedList<int> nums = new ReversedList<int>();
        nums.Add(1);
        nums.Add(2);
        nums.Add(3);
        nums.Add(4);
        // 0 1 2 3
        // 4 3 2 1
        
    }
}

