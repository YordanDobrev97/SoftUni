package core;

import model.Order;
import shared.Shop;

import java.util.List;

public class OnlineShop implements Shop {

    @Override
    public void add(Order order) {

    }

    @Override
    public Order get(int index) {
        return null;
    }

    @Override
    public int indexOf(Order order) {
        return 0;
    }

    @Override
    public Boolean contains(Order order) {
        return null;
    }

    @Override
    public Boolean remove(Order order) {
        return null;
    }

    @Override
    public Boolean remove(int id) {
        return null;
    }

    @Override
    public void set(int index, Order order) {

    }

    @Override
    public void set(Order oldOrder, Order newOrder) {

    }

    @Override
    public void clear() {

    }

    @Override
    public Order[] toArray() {
        return null;
    }

    @Override
    public void swap(Order first, Order second) {

    }

    @Override
    public List<Order> toList() {
        return null;
    }

    @Override
    public void reverse() {

    }

    @Override
    public void insert(int index, Order order) {

    }

    @Override
    public Boolean isEmpty() {
        return null;
    }

    @Override
    public int size() {
        return 0;
    }
}
