﻿namespace Git.ViewModels.Repositories
{
    public class RepositoryViewModel
    {
        public string Name { get; set; }

        public string Id { get; set; }
    }
}
