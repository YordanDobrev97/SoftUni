﻿namespace RescueRegister.Models
{
    public class Mountaineer
    {
        //TODO: Implement me
    }
}
